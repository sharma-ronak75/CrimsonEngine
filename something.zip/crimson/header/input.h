#pragma once

#include "pch.h"

namespace Crimson
{
    enum class Key;
    enum class MouseButton;
    inline constexpr int InputKeyCount = 349;
    inline constexpr int InputButtonCount = 8;

    enum struct Key{
        A = GLFW_KEY_A,
        B = GLFW_KEY_B,
        C = GLFW_KEY_C,
        D = GLFW_KEY_D,
        E = GLFW_KEY_E,
        F = GLFW_KEY_F,
        G = GLFW_KEY_G,
        H = GLFW_KEY_H,
        I = GLFW_KEY_I,
        J = GLFW_KEY_J,
        K = GLFW_KEY_K,
        L = GLFW_KEY_L,
        M = GLFW_KEY_M,
        N = GLFW_KEY_N,
        O = GLFW_KEY_O,
        P = GLFW_KEY_P,
        Q = GLFW_KEY_Q,
        R = GLFW_KEY_R,
        S = GLFW_KEY_S,
        T = GLFW_KEY_T,
        U = GLFW_KEY_U,
        V = GLFW_KEY_V,
        W = GLFW_KEY_W,
        X = GLFW_KEY_X,
        Y = GLFW_KEY_Y,
        Z = GLFW_KEY_Z,
        ZERO = GLFW_KEY_0,
        ONE = GLFW_KEY_1,
        TWO = GLFW_KEY_2,
        THREE = GLFW_KEY_3,
        FOUR = GLFW_KEY_4,
        FIVE = GLFW_KEY_5,
        SIX = GLFW_KEY_6,
        SEVEN = GLFW_KEY_7,
        EIGHT = GLFW_KEY_8,
        NINE = GLFW_KEY_9,
        MENU = GLFW_KEY_MENU,
        APOSTROPHE = GLFW_KEY_APOSTROPHE, // The key `'`
        BACKSLASH = GLFW_KEY_BACKSLASH, // The key `\`
        BACKSPACE = GLFW_KEY_BACKSPACE,
        CAPS_LOCK = GLFW_KEY_CAPS_LOCK,
        COMMA = GLFW_KEY_COMMA,
        DELETE = GLFW_KEY_DELETE,
        DOWN = GLFW_KEY_DOWN, // The key `Down Arrow`
        END = GLFW_KEY_END,
        ENTER = GLFW_KEY_ENTER,
        EQUAL = GLFW_KEY_EQUAL,
        ESCAPE = GLFW_KEY_ESCAPE,
        F1 = GLFW_KEY_F1,
        F2 = GLFW_KEY_F2,
        F3 = GLFW_KEY_F3,
        F4 = GLFW_KEY_F4,
        F5 = GLFW_KEY_F5,
        F6 = GLFW_KEY_F6,
        F7 = GLFW_KEY_F7,
        F8 = GLFW_KEY_F7,
        F9 = GLFW_KEY_F9,
        F10 = GLFW_KEY_F10,
        F11 = GLFW_KEY_F11,
        F12 = GLFW_KEY_F12,
        F13 = GLFW_KEY_F13,
        F14 = GLFW_KEY_F14,
        F15 = GLFW_KEY_F15,
        F16 = GLFW_KEY_F16,
        F17 = GLFW_KEY_F17,
        F18 = GLFW_KEY_F18,
        F19 = GLFW_KEY_F19,
        F20 = GLFW_KEY_F20,
        F21 = GLFW_KEY_F21,
        F22 = GLFW_KEY_F22,
        F23 = GLFW_KEY_F23,
        F24 = GLFW_KEY_F24,
        F25 = GLFW_KEY_F25,
        GRAVE_ACCENT = GLFW_KEY_GRAVE_ACCENT, // The key '`'
        HOME = GLFW_KEY_HOME,
        INSERT = GLFW_KEY_INSERT,
        KEYPAD_ZERO = GLFW_KEY_KP_0,
        KEYPAD_ONE = GLFW_KEY_KP_1,
        KEYPAD_TWO = GLFW_KEY_KP_2,
        KEYPAD_THREE = GLFW_KEY_KP_3,
        KEYPAD_FOUR = GLFW_KEY_KP_4,
        KEYPAD_FIVE = GLFW_KEY_KP_5,
        KEYPAD_SIX = GLFW_KEY_KP_6,
        KEYPAD_SEVEN = GLFW_KEY_KP_7,
        KEYPAD_EIGHT = GLFW_KEY_KP_8,
        KEYPAD_NINE = GLFW_KEY_KP_9,
        KEYPAD_ADD = GLFW_KEY_KP_ADD,
        KEYPAD_SUBTRACT = GLFW_KEY_KP_SUBTRACT,
        KEYPAD_MULTIPLY = GLFW_KEY_KP_MULTIPLY,
        KEYPAD_DIVIDE = GLFW_KEY_KP_DIVIDE,
        KEYPAD_EQUAL = GLFW_KEY_KP_EQUAL,
        KEYPAD_ENTER = GLFW_KEY_KP_ENTER,
        KEYPAD_DECIMAL = GLFW_KEY_KP_DECIMAL,
        KEYPAD_LEFT = GLFW_KEY_LEFT, // The key "Left Arrow"
        LEFT_ALT = GLFW_KEY_LEFT_ALT,
        LEFT_BRACKET = GLFW_KEY_LEFT_BRACKET,
        LEFT_CONTROL = GLFW_KEY_LEFT_CONTROL,
        LEFT_SHIFT = GLFW_KEY_LEFT_SHIFT,
        LEFT_SUPER = GLFW_KEY_LEFT_SUPER, // Left Window on `Windows` and Left Command on `MacOS`
        MINUS = GLFW_KEY_MINUS,
        NUM_LOCK = GLFW_KEY_NUM_LOCK,
        PAGE_DOWN = GLFW_KEY_PAGE_DOWN,
        PAGE_UP = GLFW_KEY_PAGE_UP,
        PAUSE = GLFW_KEY_PAUSE,
        PERIOD = GLFW_KEY_PERIOD, // The key `.`
        PRINT_SCREEN = GLFW_KEY_PRINT_SCREEN,
        RIGHT = GLFW_KEY_RIGHT, // The key "Right Arrow"
        RIGHT_ALT = GLFW_KEY_RIGHT_ALT,
        RIGHT_BRACKET = GLFW_KEY_RIGHT_BRACKET,
        RIGHT_CONTROL = GLFW_KEY_RIGHT_CONTROL,
        RIGHT_SHIFT = GLFW_KEY_RIGHT_SHIFT,
        RIGHT_SUPER = GLFW_KEY_RIGHT_SUPER, // Right Window on `Windows` and Right Command on `MacOS`
        SCROLL_LOCK = GLFW_KEY_SCROLL_LOCK,
        SEMICOLON = GLFW_KEY_SEMICOLON,
        SLASH = GLFW_KEY_SLASH, // The key `/`
        SPACE = GLFW_KEY_SPACE,
        TAB = GLFW_KEY_TAB,
        UNKNOWN = GLFW_KEY_UNKNOWN,
        UP = GLFW_KEY_UP, // The key "Up Arrow"
        WORLD_1 = GLFW_KEY_WORLD_1,
        WORLD_2 = GLFW_KEY_WORLD_2,
    };

    enum struct MouseButton
    {
        LEFT = GLFW_MOUSE_BUTTON_LEFT,
        RIGHT = GLFW_MOUSE_BUTTON_RIGHT,
        MIDDLE = GLFW_MOUSE_BUTTON_MIDDLE,
        ONE = GLFW_MOUSE_BUTTON_1,
        TWO = GLFW_MOUSE_BUTTON_2,
        THREE = GLFW_MOUSE_BUTTON_3,
        FOUR = GLFW_MOUSE_BUTTON_4,
        FIVE = GLFW_MOUSE_BUTTON_5,
        SIX = GLFW_MOUSE_BUTTON_6,
        SEVEN = GLFW_MOUSE_BUTTON_7,
        EIGHT = GLFW_MOUSE_BUTTON_8,
    };
};

namespace Crimson::Input
{
    extern GLFWwindow* window;
    extern bool mouse_down;
    extern glm::ivec2 mouse_position;
    extern glm::vec2 mouse_delta;
    extern bool keys[InputKeyCount]; // Keys pressed
    extern bool buttons[InputButtonCount]; // Mouse button pressed
    extern bool prevKeys[InputKeyCount]; // Keys pressed in last frame
    extern bool prevButtons[InputButtonCount];

    void listen();
    bool is_key_down(Key key);
    bool is_key_pressed(Key key);
    bool is_key_released(Key key);
    bool is_mouse_down(MouseButton button);
    bool is_mouse_pressed(MouseButton button);
    bool is_mouse_released(MouseButton button);
}